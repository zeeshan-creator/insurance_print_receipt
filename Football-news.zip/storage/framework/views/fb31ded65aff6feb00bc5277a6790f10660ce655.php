<!-- BEGIN: Theme CSS-->
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
    href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
    rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset(mix('assets/vendor/fonts/boxicons.css'))); ?>" />

<!-- Core CSS -->
<link rel="stylesheet" href="<?php echo e(asset(mix('assets/vendor/css/core.css'))); ?>" />
<link rel="stylesheet" href="<?php echo e(asset(mix('assets/vendor/css/theme-default.css'))); ?>" />

<link rel="stylesheet" href="<?php echo e(asset(mix('assets/css/sweetalert2.min.css'))); ?>" />
<link rel="stylesheet" href="<?php echo e(asset(mix('assets/css/dropify.min.css'))); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('/assets/css/summernote-bs4.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('/assets/css/dataTables.min.css')); ?>" />



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />

<link rel="stylesheet" href="<?php echo e(asset('/assets/css/app.css')); ?>" />




<link rel="stylesheet" href="<?php echo e(asset(mix('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css'))); ?>" />




<!-- Vendor Styles -->
<?php echo $__env->yieldContent('vendor-style'); ?>


<!-- Page Styles -->
<?php echo $__env->yieldContent('page-style'); ?>

<?php if(app()->getLocale() == 'ar'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/arabic.css')); ?>" />
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\working_area\Football-news\resources\views/layouts/sections/styles.blade.php ENDPATH**/ ?>