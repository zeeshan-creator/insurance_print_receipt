<?php

namespace App\Http\Controllers;

use App\Models\promotion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class API_promotionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $token = $request->input('api_token');
        $user = DB::table('users')->select('id')->where('api_token', '=', hash('sha256', $token))->get();
        $user_id = get_object_vars($user[0])['id'];

        $promotion = DB::table('promotions')->where('user_id', '=', $user_id)->get();

        return $promotion;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $token = $request->input('api_token');
        $user = DB::table('users')->select('id')->where('api_token', '=', hash('sha256', $token))->get();
        $user_id = get_object_vars($user[0])['id'];


        $data = new promotion();
        $data['user_id'] = $user_id;
        $data['name'] = $request->input('name');
        $data['image'] = $request->input('image');
        $data['url'] = $request->input('url');
        $data['start_date'] = $request->input('start_date');
        $data['exp_date'] = $request->input('exp_date');
        $data->save();

        return  response()->json($data, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {

        $token = $request->input('api_token');
        $user = DB::table('users')->select('id')->where('api_token', '=', hash('sha256', $token))->get();
        $user_id = get_object_vars($user[0])['id'];

        $promotion = DB::table('promotions')->where('user_id', '=', $user_id)->where('id', '=', $id)->get();


        return $promotion;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = promotion::findOrFail($id);

        $token = $request->input('api_token');
        $user = DB::table('users')->select('id')->where('api_token', '=', hash('sha256', $token))->get();
        $user_id = get_object_vars($user[0])['id'];

        if ($data['user_id'] != $user_id) {
            return response()->json(null, 404);
        }

        $data['name'] = $request->input('name');
        $data['image'] = $request->input('image');
        $data['url'] = $request->input('url');
        $data['start_date'] = $request->input('start_date');
        $data['exp_date'] = $request->input('exp_date');

        $data->save();

        $data->fill($request->all())->save();

        return response()->json($data, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $data = promotion::findOrFail($id);

        $token = $request->input('api_token');
        $user = DB::table('users')->select('id')->where('api_token', '=', hash('sha256', $token))->get();
        $user_id = get_object_vars($user[0])['id'];

        if ($data['user_id'] != $user_id) {
            return response()->json(null, 404);
        }

        File::delete("images/" . $data->image);

        $data->delete();

        return response()->json(null, 204);
    }
}
