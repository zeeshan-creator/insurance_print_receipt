<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;


class API_userController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // return User::all();
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $data = new User();
        $api_token = Str::random(60);
        $data['api_token']  = hash('sha256', $api_token);
        $data['first_name']  = $request->input('first_name');
        $data['last_name']   = $request->input('last_name');
        $data['email']       = $request->input('email');
        $data['password']    = Hash::make($request->input('password'));
        $data->save();

        return  response()->json($api_token, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            $user = DB::table('users')->select('id', 'first_name', 'last_name', 'email')->where('id', '=', Auth::id())->get();
            return response()->json($user, 200);
        }

        return response()->json(null, 404);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $token = $request->input('api_token');
        $user = DB::table('users')->select('id')->where('api_token', '=', hash('sha256', $token))->get();
        $user_id = get_object_vars($user[0])['id'];

        $data = User::findOrFail($user_id);

        $data['first_name']  = $request->input('first_name');
        $data['last_name']   = $request->input('last_name');
        $data['email']       = $request->input('email');
        $data['password']    = Hash::make($request->input('password'));
        $data->save();

        return response()->json($data, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // $User = User::findOrFail($id);
        // $User->delete();

        // return response()->json(null, 204);
    }
}
