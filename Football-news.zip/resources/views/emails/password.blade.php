@component('mail::message')
    # Password Reset Token

    Your Token : {{ $token }}
@endcomponent
