<?php

// lang/en/messages.php

return [
    'welcome' => 'Welcome, :Name',
    'apples' => '{0} There are none|[1,19] There are some|[20,*] There are many',
    'minutes_ago' => '{1} :count minute ago|[2,*] :count minutes ago',
];
